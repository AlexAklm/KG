from enum import Enum


class ProjectionMode(Enum):
    ORTHO = 1
    PERSPECTIVE = 2