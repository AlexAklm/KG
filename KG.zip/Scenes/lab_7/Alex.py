from Common.Model_VBO import *


def draw(Width, Height):
    deer = Model('./Models/Deer.obj')
    deer.render()
