from Common.Model import *


def draw(Width, Height):
    deer = Model('./Models/Deer.obj')
    deer.render()
